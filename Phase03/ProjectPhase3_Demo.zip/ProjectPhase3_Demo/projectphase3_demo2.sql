use aeromanagex;

create table pilot (pilot_ID int, pilot_FName varchar(45), pilot_LName varchar(45),hire_date date, pilot_DOB datetime(6));

insert into pilot 
	(pilot_ID, pilot_FName, pilot_LName, hire_date, pilot_DOB) 
    values (135792468, 'George', 'Washington', '1776-07-04','1732-02-22 10:30:00');
insert into pilot 
	(pilot_ID, pilot_FName, pilot_LName, hire_date, pilot_DOB) 
    values (246813579, 'Dwayne', 'Johnson', '1996-03-10','1972-05-02 13:45:00');
insert into pilot 
	(pilot_ID, pilot_FName, pilot_LName, hire_date, pilot_DOB) 
    values (667428, 'Isaac', 'Newton', '1687-07-07','1643-01-04 12:25:16.42');

table pilot;