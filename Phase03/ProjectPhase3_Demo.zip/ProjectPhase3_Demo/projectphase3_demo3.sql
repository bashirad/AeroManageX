use aeromanagex;
CREATE TABLE book (
  id int,
  title VARCHAR(200),
  tags JSON,
  PRIMARY KEY (id)
) ;

INSERT INTO book (title, tags)
VALUES (
  'Pride and Predjudice',
  '["Novel", "Fiction", "Romance"]'
);

INSERT INTO book (title, tags)
VALUES (
  'Moby Dick',
  '["Adventure", "Fiction", "Epic"]'
);
select * from book;

select json_arrayagg(title) from book;