use aeromanagex;


-- Evaluates a (possibly empty) list of values and returns a JSON array containing those values.
select json_array(12601, "Spirit Airlines", null);

-- Evaluates a (possibly empty) list of key-value pairs and returns a JSON 
-- object containing those pairs. An error occurs if any key name is NULL or the number of arguments is odd.
select json_object('Bashir','3C', 'Marguerite', '13A', 'Nihar', '18F', 'Bob');


select json_object('Bashir','3C', 'Marguerite', '13A', 'Nihar', '18F', 'Bob', '22E');

-- Returns 0 or 1 to indicate whether a value is valid JSON. Returns NULL if the argument is NULL.
SELECT JSON_VALID('{"Bashir": "3C"}');

SELECT JSON_VALID(null);

--

CREATE TABLE people(json_col JSON);
 
INSERT INTO people VALUES (
    '{ "people": [
        { "name":"John Smith",  "address":"123 1st Ave, NY, NY"}, 
        { "name":"Sally Brown",  "address":"246 2nd Ave, NY, NY"}, 
        { "name":"John Johnson",  "address":"1357 3rd Ave, NY, NY"}
     ] }'
);

select * from people; 

SELECT people.* FROM people, 
     JSON_TABLE(json_col, '$.people[*]' COLUMNS (
                FandLname VARCHAR(40)  PATH '$.name',
                address VARCHAR(100) PATH '$.address')
     ) people;

