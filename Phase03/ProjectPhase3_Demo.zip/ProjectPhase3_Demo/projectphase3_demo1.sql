use aeromanagex;

create table flight (flight_ID int, dep_time time(3), dep_date datetime(6), dep_ts timestamp(0), dep_year year(4));

insert into flight 
	(dep_time, dep_date, dep_ts, flight_ID, dep_year) 
    values ('00:08:05', '2023-10-01 00:08:05', '2023-10-01 00:08:05','1234567890','2023');
insert into flight 
	(dep_time, dep_date, dep_ts, flight_ID, dep_year)
    values ('00:12:30', '2023-12-25 00:12:30', '2023-12-25 00:12:30','0987654321','2023');

table flight;
